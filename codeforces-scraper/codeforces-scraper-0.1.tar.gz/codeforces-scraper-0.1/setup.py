from setuptools import setup
setup(name='codeforces-scraper',
  version='0.1',
  description='codeforces-scraper',
  author='m1m3',
  license='MIT',
  packages=['main'],
  entry_points = {
    'gui_scripts': ['main=main.command_line:main'],
    },
  zip_safe=False)



